#include "header.h"

int main()
{
    srand (time(NULL));
    initiateMatrix();    // /Initialitation of the random char
    
while (1){   

    getSize();

    printScreen(ciclo,lineTotal,wideTotal);

    wait();

    clearScreen();

    moveScreen();



    }
}
