#ifndef HEADER_H
#define HEADER_H
#include <iostream>
#include <stdio.h>      
#include <stdlib.h>     
#include <time.h>       
#include <sys/ioctl.h>
using namespace std;
#endif // HEADER_H

char matrixPrincipal[1920][1080];
char baseRamdon[]="0123456789/*-+qwertyuiopasdfghjklzxcvbnm!@#$%^&*()-=][';/.,                                                                                                                                                                                                                                                                                      ";
int size = sizeof (baseRamdon)/ sizeof (baseRamdon[0])-1;
int colum = 1080;
int line = 1920;
int slower=0;
int ciclo=0;
int lineTotal, wideTotal;
struct winsize wide;
int limit=-1;

/**
*With this I create the matrix that I will be printing into the screen.
*/
void initiateMatrix(){             
    for(int x=0; x<line; x++){
            for(int y=0; y<colum; y++){
                matrixPrincipal[x][y]=baseRamdon[rand()%size];
            }
    }
}

 /**
*Tecnicly this allow me to have the account of how many lines do I need to move down each time a cycle ends.
*/

void moveScreen(){                 
    ciclo= ciclo+1;  

    if (ciclo==1080){
        ciclo=0;
        limit=-1;
        initiateMatrix();
    }

}

/**
*Print the values of a internal structure char.
*/


void printScreen(int cycleNum,int linesT,int columT){     


    if(cycleNum>linesT){
        limit=limit+1;
    }


    for(int n=cycleNum; n>limit; n--){
        for (int m=0; m<columT; m++){
            cout << "\033[1;32m" << matrixPrincipal[n][m] << "\33[0m";
           }
        cout << endl;
    }
}

/**
*I created a loop longer enough to stop the process for a while. 
*/
void wait(){                       
    while(slower < 90000000) {
        slower++;
        }
        slower = 0;

}

/**
*The easier way to made it commpatible with both Win and Unix is ask the system if he have the windows directory.
*/

void clearScreen(){                 

    if(getenv("windir")!=NULL){
       system("CLS");
    }

    else if(getenv("windir")==NULL){
        system("clear");
    }
}

/**
*I get the wide and long of the window where I'm printing.
*/

void getSize(){                           
    ioctl(0, TIOCGWINSZ, &wide);
    lineTotal = wide.ws_row;
    wideTotal = wide.ws_col;

}
