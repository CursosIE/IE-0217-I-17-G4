var searchData=
[
  ['limit',['limit',['../a00001.html#a093d9695bc7f56e2e457d8ccf15652c1',1,'header.h']]],
  ['line',['line',['../a00001.html#a41ebd28ef1d7c6ade45642cb6acc1039',1,'header.h']]],
  ['linetotal',['lineTotal',['../a00001.html#ac7bdfc4d1d831331e00b462804507e72',1,'header.h']]]
];
