var searchData=
[
  ['clearscreen',['clearScreen',['../a00001.html#a9d7e8af417b6d543da691e9c0e2f6f9f',1,'header.h']]]
];
