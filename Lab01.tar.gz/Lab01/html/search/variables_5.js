var searchData=
[
  ['wide',['wide',['../a00001.html#a9aee18d200942adc099ed53c1821a2ee',1,'header.h']]],
  ['widetotal',['wideTotal',['../a00001.html#a25e573dba79d66d399b4c658f69907bf',1,'header.h']]]
];
