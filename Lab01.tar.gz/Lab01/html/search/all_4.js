var searchData=
[
  ['initiatematrix',['initiateMatrix',['../a00001.html#ac74d55bd2d8cc7c65264980a0d6e9dfd',1,'header.h']]]
];
