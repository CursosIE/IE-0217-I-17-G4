var searchData=
[
  ['ciclo',['ciclo',['../a00001.html#af843866b0f315aebc8103b4ff2dffefe',1,'header.h']]],
  ['clearscreen',['clearScreen',['../a00001.html#a9d7e8af417b6d543da691e9c0e2f6f9f',1,'header.h']]],
  ['colum',['colum',['../a00001.html#a3f36046a14d754389d2a4496e6e87157',1,'header.h']]]
];
