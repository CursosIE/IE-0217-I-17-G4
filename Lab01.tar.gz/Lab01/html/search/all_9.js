var searchData=
[
  ['wait',['wait',['../a00001.html#aa3b21853f890838c88d047d6c2786917',1,'header.h']]],
  ['wide',['wide',['../a00001.html#a9aee18d200942adc099ed53c1821a2ee',1,'header.h']]],
  ['widetotal',['wideTotal',['../a00001.html#a25e573dba79d66d399b4c658f69907bf',1,'header.h']]]
];
