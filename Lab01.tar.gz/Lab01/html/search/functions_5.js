var searchData=
[
  ['wait',['wait',['../a00001.html#aa3b21853f890838c88d047d6c2786917',1,'header.h']]]
];
