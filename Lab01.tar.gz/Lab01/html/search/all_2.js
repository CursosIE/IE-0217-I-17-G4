var searchData=
[
  ['getsize',['getSize',['../a00001.html#aac22adfdbb1cb9106a2d44041c1a6576',1,'header.h']]]
];
